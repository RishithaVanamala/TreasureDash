# Coin Rush 2

This is a 2.5D game in which the player collects different pickups and score increments acoordingly. If the player touches enemies then game will be over.